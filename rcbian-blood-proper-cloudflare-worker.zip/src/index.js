export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Let Workers Static Assets serve the complete site.
    return env.ASSETS.fetch(request);
  },
};
